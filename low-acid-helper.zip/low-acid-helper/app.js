const foodDB = [
  {
    keys: ["pretzel", "pretzels"],
    status: "safe-ish",
    answer: "Pretzels are usually a decent low-acid snack, especially plain ones. Watch the salt, portion size, and whether dryness makes throat symptoms feel worse.",
    ideas: ["Plain pretzels + water", "Pretzels + banana", "Pretzels + low-fat cottage cheese if dairy is tolerated"]
  },
  {
    keys: ["nuts", "nut", "almond", "almonds", "cashew", "cashews", "peanut", "peanuts", "walnut", "walnuts"],
    status: "maybe",
    answer: "Nuts are not very acidic, but they are higher-fat, and fat can trigger reflux for some people. Try a small handful, avoid spicy/flavored nuts, and avoid eating them close to bedtime.",
    ideas: ["Small handful of plain almonds", "A few cashews with oatmeal", "Nut butter thinly spread, not a huge spoonful"]
  },
  {
    keys: ["banana", "bananas"],
    status: "safe-ish",
    answer: "Bananas are one of the easiest low-acid choices for many people with reflux. They are especially useful as a quick snack or breakfast add-on.",
    ideas: ["Banana + oatmeal", "Banana + rice cakes", "Banana + low-fat yogurt if tolerated"]
  },
  {
    keys: ["melon", "watermelon", "cantaloupe", "honeydew"],
    status: "safe-ish",
    answer: "Melons are usually lower-acid and gentle. They are a good fruit choice when citrus or berries feel risky.",
    ideas: ["Melon cup", "Melon + plain crackers", "Melon + low-fat cottage cheese if tolerated"]
  },
  {
    keys: ["oatmeal", "oats"],
    status: "safe-ish",
    answer: "Oatmeal is a strong low-acid default: filling, bland in a good way, and easy to pair with banana or melon.",
    ideas: ["Plain oatmeal + banana", "Overnight oats with low-fat milk", "Instant plain oats from the store"]
  },
  {
    keys: ["yogurt", "greek yogurt", "cottage cheese", "dairy", "milk"],
    status: "maybe",
    answer: "Low-fat dairy is tolerated by some people and not by others. Full-fat dairy is more trigger-prone. Choose plain low-fat or nonfat, and skip citrus/chocolate flavors.",
    ideas: ["Plain nonfat Greek yogurt + banana", "Low-fat cottage cheese + melon", "Small portion first"]
  },
  {
    keys: ["coffee", "caffeine", "tea", "energy drink"],
    status: "trigger-prone",
    answer: "Coffee and caffeine are common reflux triggers. If symptoms are active, this is one of the first things to reduce or swap.",
    ideas: ["Water", "Non-mint herbal tea", "Small low-acid coffee only if personally tolerated"]
  },
  {
    keys: ["soda", "sparkling", "carbonated", "seltzer"],
    status: "trigger-prone",
    answer: "Carbonation can worsen reflux for many people because it adds pressure and burping. Flat water is safer during a flare.",
    ideas: ["Water", "Still electrolyte drink without citrus", "Decaf non-mint tea"]
  },
  {
    keys: ["tomato", "tomatoes", "pizza", "marinara", "ketchup", "salsa"],
    status: "trigger-prone",
    answer: "Tomato-based foods are acidic and commonly trigger reflux/LPR. During a flare, skip marinara, salsa, ketchup, and pizza sauce.",
    ideas: ["Plain olive-oil pasta in a small portion", "Rice bowl without salsa", "Sandwich without tomato"]
  },
  {
    keys: ["orange", "citrus", "lemon", "lime", "grapefruit", "pineapple"],
    status: "trigger-prone",
    answer: "Citrus and pineapple are acidic and commonly trigger LPR symptoms. Save these for times when symptoms are calm, if tolerated at all.",
    ideas: ["Banana", "Melon", "Applesauce if tolerated"]
  },
  {
    keys: ["chocolate", "mint", "peppermint"],
    status: "trigger-prone",
    answer: "Chocolate and mint are classic reflux triggers for many people. Peppermint can be especially sneaky in gum, tea, and candies.",
    ideas: ["Vanilla low-fat yogurt if tolerated", "Banana", "Plain graham crackers"]
  },
  {
    keys: ["spicy", "hot sauce", "jalapeno", "pepper", "curry"],
    status: "trigger-prone",
    answer: "Spicy foods are trigger-prone for LPR. During flare-up mode, avoid hot sauce, jalapeños, chili flakes, and spicy seasoning blends.",
    ideas: ["Use herbs instead", "Small amount of salt", "Basil, parsley, oregano, or ginger if tolerated"]
  },
  {
    keys: ["egg", "eggs", "boiled egg"],
    status: "maybe",
    answer: "Eggs can work for some people, but the yolk adds fat. If symptoms are active, egg whites or a small portion may be safer than a greasy egg sandwich.",
    ideas: ["Hard-boiled egg + crackers", "Egg whites + toast", "Avoid fried/greasy eggs during a flare"]
  },
  {
    keys: ["hummus", "chickpea", "chickpeas"],
    status: "maybe",
    answer: "Hummus can be okay, but many versions contain lemon and garlic, which can bother LPR. Try a small amount or choose a mild version.",
    ideas: ["Mild hummus + pita", "Chickpeas rinsed on a rice bowl", "Skip spicy hummus"]
  }
];

const safeIdeas = {
  lunch: [
    "Turkey or chicken sandwich on whole-grain bread with lettuce/cucumber; skip tomato, onion, spicy mustard, and heavy mayo.",
    "Rice bowl with plain rice, steamed vegetables, and a lean/simple protein. Keep sauces mild and non-tomato.",
    "Baked potato or sweet potato with a light topping. Avoid butter overload, chili, salsa, and spicy toppings.",
    "Oatmeal or overnight oats with banana if lunch needs to be extremely gentle.",
    "Plain pasta or rice with vegetables and a small amount of olive oil; skip marinara."
  ],
  vegetarianLunch: [
    "Rice bowl with plain rice, steamed vegetables, chickpeas if tolerated, and a mild dressing on the side.",
    "Baked potato or sweet potato with low-fat cottage cheese if dairy is tolerated.",
    "Oatmeal with banana when symptoms are active and you need a boring-but-safe meal.",
    "Egg-white or small egg sandwich on toast with lettuce; skip tomato, onion, and spicy condiments.",
    "Plain pasta with vegetables and a small amount of olive oil; no marinara."
  ],
  snacks: [
    "Banana",
    "Melon cup",
    "Plain pretzels",
    "Rice cakes",
    "Plain oatmeal cup",
    "Low-fat cottage cheese with melon if tolerated",
    "Plain crackers",
    "Small handful of plain nuts if fat does not trigger symptoms"
  ],
  strictSnacks: [
    "Banana",
    "Plain oatmeal",
    "Plain rice cakes",
    "Melon",
    "Plain pretzels with water",
    "Toast or plain crackers"
  ],
  avoid: [
    "Tomato sauce, salsa, ketchup, and pizza sauce",
    "Citrus: orange, lemon, lime, grapefruit, pineapple",
    "Spicy foods and hot sauce",
    "Fried/greasy foods and heavy creamy meals",
    "Chocolate and peppermint/mint",
    "Coffee/caffeine, soda, carbonation, and alcohol",
    "Large meals and eating close to bedtime"
  ],
  publix: [
    "Produce: bananas, melon cup, cucumber, lettuce, sweet potatoes or microwave potatoes.",
    "Bakery/bread: whole-grain bread, plain bagels, plain crackers, rice cakes, pretzels.",
    "Protein: plain deli turkey/chicken, hard-boiled eggs, tuna/chicken packets if tolerated. Avoid spicy or mayo-heavy prepared salads during a flare.",
    "Dairy if tolerated: low-fat cottage cheese, plain nonfat Greek yogurt. Skip citrus/chocolate flavors.",
    "Prepared-food rule: avoid fried chicken, pizza, tomato soups, spicy sauces, onions, and heavy creamy sides when symptoms are active."
  ],
  publixVegetarian: [
    "Produce: bananas, melon cup, cucumber, lettuce, sweet potatoes or microwave potatoes.",
    "Dry goods: oatmeal cups, rice cakes, plain pretzels, plain crackers, microwave rice cups.",
    "Protein-ish: hard-boiled eggs, chickpeas if tolerated, mild hummus in a small amount, low-fat cottage cheese if dairy is tolerated.",
    "Easy meal: microwave rice + cucumber/lettuce + chickpeas or egg + mild dressing on the side.",
    "Avoid during a flare: tomato soups, salsa, citrus fruit cups, spicy prepared foods, fried sides, and chocolate/mint snacks."
  ]
};

const elements = {
  questionInput: document.getElementById("questionInput"),
  askButton: document.getElementById("askButton"),
  answerCard: document.getElementById("answerCard"),
  copyPromptButton: document.getElementById("copyPromptButton"),
  copyStatus: document.getElementById("copyStatus"),
  strictMode: document.getElementById("strictMode"),
  vegetarianMode: document.getElementById("vegetarianMode"),
  noDairyMode: document.getElementById("noDairyMode"),
  setupPanel: document.getElementById("setupPanel"),
  installHelp: document.getElementById("installHelp"),
  logInput: document.getElementById("logInput"),
  saveLogButton: document.getElementById("saveLogButton"),
  showLogButton: document.getElementById("showLogButton"),
  clearLogButton: document.getElementById("clearLogButton"),
  logOutput: document.getElementById("logOutput")
};

let lastQuestion = "I’m at Publix. What can I buy for lunch?";
let lastAnswerText = "";

function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, char => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    "\"": "&quot;",
    "'": "&#039;"
  }[char]));
}

function getPrefs() {
  return {
    strict: elements.strictMode.checked,
    vegetarian: elements.vegetarianMode.checked,
    noDairy: elements.noDairyMode.checked
  };
}

function savePrefs() {
  localStorage.setItem("lowAcidPrefs", JSON.stringify(getPrefs()));
}

function loadPrefs() {
  try {
    const prefs = JSON.parse(localStorage.getItem("lowAcidPrefs") || "{}");
    elements.strictMode.checked = Boolean(prefs.strict);
    elements.vegetarianMode.checked = Boolean(prefs.vegetarian);
    elements.noDairyMode.checked = Boolean(prefs.noDairy);
  } catch (_) {}
}

function listHTML(items) {
  return `<ul>${items.map(item => `<li>${escapeHTML(item)}</li>`).join("")}</ul>`;
}

function renderAnswer(title, badge, blocks) {
  lastAnswerText = blocks.map(block => `${block.heading}: ${block.body || ""} ${(block.items || []).join("; ")}`).join("\n");
  elements.answerCard.innerHTML = `
    <div class="answer-header">
      <h2>${escapeHTML(title)}</h2>
      <span class="badge">${escapeHTML(badge)}</span>
    </div>
    ${blocks.map(block => `
      <div class="answer-block">
        <h3>${escapeHTML(block.heading)}</h3>
        ${block.body ? `<p>${escapeHTML(block.body)}</p>` : ""}
        ${block.items ? listHTML(block.items) : ""}
      </div>
    `).join("")}
  `;
}

function findFood(question) {
  const q = question.toLowerCase();
  return foodDB.find(food => food.keys.some(key => q.includes(key)));
}

function removeDairy(items) {
  return items.filter(item => !/yogurt|cottage cheese|dairy|milk|cheese/i.test(item));
}

function answerQuestion(question) {
  const q = question.trim().toLowerCase();
  const prefs = getPrefs();
  lastQuestion = question.trim() || lastQuestion;

  if (!q) {
    renderAnswer("Ask me something first", "ready", [{ heading: "Examples", items: ["What about pretzels?", "I’m at Publix, what can I buy?", "Give me 5 snacks."] }]);
    return;
  }

  const food = findFood(q);
  if (food) {
    let ideas = [...food.ideas];
    if (prefs.noDairy) ideas = removeDairy(ideas);
    if (prefs.strict && food.status === "maybe") {
      renderAnswer(`About ${food.keys[0]}`, "maybe", [
        { heading: "Bottom line", body: `${food.answer} Since strict flare-up mode is on, treat this as a small-test food, not a default.` },
        { heading: "Safer move today", items: ["Choose banana, oatmeal, melon, rice cakes, plain crackers, or plain pretzels instead."] }
      ]);
      return;
    }
    renderAnswer(`About ${food.keys[0]}`, food.status, [
      { heading: "Bottom line", body: food.answer },
      { heading: "How to try it", items: ideas.length ? ideas : ["Try a small portion and track symptoms."] }
    ]);
    return;
  }

  if (q.includes("publix") || q.includes("store") || q.includes("grocery")) {
    let items = prefs.vegetarian ? safeIdeas.publixVegetarian : safeIdeas.publix;
    if (prefs.noDairy) items = removeDairy(items);
    renderAnswer("Publix game plan", prefs.strict ? "strict" : "store mode", [
      { heading: "Buy these", items },
      { heading: "Fast lunch combo", body: prefs.vegetarian
        ? "Microwave rice cup + cucumber/lettuce + chickpeas or egg + banana. Keep sauce mild and on the side."
        : "Whole-grain turkey/chicken sandwich + banana or melon. Skip tomato, onion, spicy mustard, and heavy mayo." }
    ]);
    return;
  }

  if (q.includes("lunch") || q.includes("meal") || q.includes("eat")) {
    let items = prefs.vegetarian ? safeIdeas.vegetarianLunch : safeIdeas.lunch;
    if (prefs.noDairy) items = removeDairy(items);
    renderAnswer("Low-acid lunch ideas", prefs.strict ? "gentle" : "practical", [
      { heading: "Pick one", items },
      { heading: "Rule of thumb", body: "Keep it smaller, lower-fat, non-spicy, and non-tomato. Stay upright after eating." }
    ]);
    return;
  }

  if (q.includes("snack") || q.includes("quick")) {
    let items = prefs.strict ? safeIdeas.strictSnacks : safeIdeas.snacks;
    if (prefs.noDairy) items = removeDairy(items);
    renderAnswer("Snack ideas", prefs.strict ? "strict" : "safe-ish", [
      { heading: "Easy options", items },
      { heading: "Avoid making it worse", body: "Do not combine snacks with coffee, soda, citrus, chocolate, mint, hot sauce, or a huge portion." }
    ]);
    return;
  }

  if (q.includes("avoid") || q.includes("bad") || q.includes("trigger")) {
    renderAnswer("Common LPR trigger-prone foods", "avoid", [
      { heading: "Be careful with", items: safeIdeas.avoid },
      { heading: "Important", body: "Individual triggers vary. If a food repeatedly causes throat burn, mucus, cough, hoarseness, or globus feeling, log it and avoid it for now." }
    ]);
    return;
  }

  renderAnswer("Best guess", "general", [
    { heading: "Simple answer", body: "For LPR, aim for low-acid, lower-fat, non-spicy, smaller portions. Good defaults are oatmeal, banana, melon, rice, potatoes, plain crackers, pretzels, whole grains, and mild proteins." },
    { heading: "To get a better answer", body: "Ask about one food or one situation, like ‘What about almonds?’ or ‘I’m at Publix and need lunch.’" }
  ]);
}

async function copyAIprompt() {
  const prefs = getPrefs();
  const prompt = `You are my practical LPR / low-acid food helper. Keep the answer short, realistic, and grocery-store friendly.\n\nMy question: ${lastQuestion}\n\nMy preferences: ${prefs.strict ? "strict flare-up mode; " : "normal cautious mode; "}${prefs.vegetarian ? "vegetarian; " : "not necessarily vegetarian; "}${prefs.noDairy ? "avoid dairy; " : "dairy is okay if tolerated; "}\n\nWhat I already got from my offline helper:\n${lastAnswerText || "No answer yet."}\n\nPlease give me: 1) safest option, 2) maybe option, 3) avoid/trigger-prone option, and 4) what to buy if I am at Publix.`;

  try {
    await navigator.clipboard.writeText(prompt);
    elements.copyStatus.textContent = "Copied. Now paste it into ChatGPT or Google.";
  } catch (_) {
    elements.copyStatus.textContent = "Copy failed. Select and copy this:";
    alert(prompt);
  }
}

function getLog() {
  try { return JSON.parse(localStorage.getItem("lowAcidLog") || "[]"); }
  catch (_) { return []; }
}

function saveLog() {
  const text = elements.logInput.value.trim();
  if (!text) return;
  const log = getLog();
  log.unshift({ text, date: new Date().toLocaleString() });
  localStorage.setItem("lowAcidLog", JSON.stringify(log.slice(0, 50)));
  elements.logInput.value = "";
  showLog();
}

function showLog() {
  const log = getLog();
  if (!log.length) {
    elements.logOutput.innerHTML = "<p>No trigger notes yet.</p>";
    return;
  }
  elements.logOutput.innerHTML = log.map(item => `
    <div class="log-item">
      <strong>${escapeHTML(item.date)}</strong><br />
      ${escapeHTML(item.text)}
    </div>
  `).join("");
}

function clearLog() {
  if (confirm("Clear the local trigger log on this phone?")) {
    localStorage.removeItem("lowAcidLog");
    showLog();
  }
}

elements.askButton.addEventListener("click", () => answerQuestion(elements.questionInput.value));
elements.questionInput.addEventListener("keydown", event => {
  if (event.key === "Enter") answerQuestion(elements.questionInput.value);
});
document.querySelectorAll(".chip").forEach(button => {
  button.addEventListener("click", () => {
    elements.questionInput.value = button.dataset.prompt;
    answerQuestion(button.dataset.prompt);
  });
});
[elements.strictMode, elements.vegetarianMode, elements.noDairyMode].forEach(input => input.addEventListener("change", savePrefs));
elements.copyPromptButton.addEventListener("click", copyAIprompt);
elements.installHelp.addEventListener("click", () => elements.setupPanel.classList.toggle("hidden"));
elements.saveLogButton.addEventListener("click", saveLog);
elements.showLogButton.addEventListener("click", showLog);
elements.clearLogButton.addEventListener("click", clearLog);

loadPrefs();
if ("serviceWorker" in navigator) {
  navigator.serviceWorker.register("service-worker.js").catch(() => {});
}
