# Low-Acid Food Helper

A no-API, no-backend, iPhone-friendly static web app for quick LPR / low-acid food decisions.

## What it does

- Works without an OpenAI API key.
- Gives local rule-based guidance for common LPR food questions.
- Has quick buttons for Publix lunch, snacks, nuts, pretzels, and avoid-list guidance.
- Has optional preference toggles: strict flare-up mode, vegetarian, avoid dairy.
- Saves a mini trigger log locally on the phone using localStorage.
- Can copy a clean follow-up prompt for ChatGPT/Google when the user wants true AI back-and-forth.

## How to use locally

Open `index.html` in a browser.

## How to make it feel like an iPhone app

1. Upload this folder to any static HTTPS host:
   - GitHub Pages
   - Netlify
   - Cloudflare Pages
   - Vercel static site
   - Any normal web host
2. Open the hosted link in Safari on the iPhone.
3. Tap Share → Add to Home Screen.
4. Name it `Low Acid`.

## No API key needed

This app does not call OpenAI, Google, or any backend. The “Copy AI follow-up” button only copies text to the clipboard so the user can paste into whichever assistant they already use.

## Medical note

This is practical food guidance, not medical advice. LPR triggers vary. The user should follow their clinician’s plan if it differs.
